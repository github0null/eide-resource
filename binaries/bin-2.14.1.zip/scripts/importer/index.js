import { x2js } from 'lib/x2js/x2js.js';
import { main as importer } from 'importer/Segger_Embedded_Studio.js';

if (scriptArgs.length < 2) {
    throw new Error(`params too less !, format: <program> <project file path>`)
}

const prjFilePath = scriptArgs[1];

const parser = new x2js({
    arrayAccessForm: 'none',
    attributePrefix: '$',
    selfClosingElements: true,
    keepText: true
});

const pathPart = prjFilePath.replace(/\\/g, '/').split('/');
pathPart.splice(pathPart.length - 1, 1);
const prjInfo = importer(parser, std.loadFile(prjFilePath), pathPart.join('/'));

print(JSON.stringify(prjInfo, undefined, 4));
