import { x2js } from 'lib/x2js/x2js.js';

const parser = new x2js();

const val = `<t>
                <a>hhh</>
                <a>hhh</>
                <a>hhh</>
            </t>`;


print(parser.xml2json(val));
